#include <gtk/gtk.h>


void
on_buttonajouteroffre_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonafficheroffre_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonsupprimeroffre_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonafficheroffre2_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonmodifoffre_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_connexion_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

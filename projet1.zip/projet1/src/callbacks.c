#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "function.h"

void
on_buttonajouter_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *aceuil;
window=lookup_widget(button,"aceuil");
gtk_widget_hide(window);
aceuil=create_ajout();
gtk_widget_show_all(aceuil);
}


void
on_buttonmodifier_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *aceuil;
window=lookup_widget(button,"aceuil");
gtk_widget_hide(window);
aceuil=create_modification();
gtk_widget_show_all(aceuil);
}


void
on_buttonsupprimer_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *aceuil;
window=lookup_widget(button,"aceuil");
gtk_widget_hide(window);
aceuil=create_supression();
gtk_widget_show_all(aceuil);
}


void
on_buttonafficher_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *aceuil;
GtkWidget *treeview1;
window=lookup_widget(button,"aceuil");
gtk_widget_hide(window);
aceuil=create_affichage();
gtk_widget_show_all(aceuil);
treeview1=lookup_widget(aceuil,"treeview1");
affich(treeview1);
}











void
on_buttonback1_clicked                 (GtkWidget      *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *ajout;
window=lookup_widget(button,"ajout");
gtk_widget_hide(window);
ajout=create_aceuil();
gtk_widget_show_all(ajout);

}


void
on_buttonback2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *modification;
window=lookup_widget(button,"modification");
gtk_widget_hide(window);
modification=create_aceuil();
gtk_widget_show_all(modification);

}


void
on_buttonback3_clicked                 (GtkWidget        *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *supression;
window=lookup_widget(button,"supression");
gtk_widget_hide(window);
supression=create_aceuil();
gtk_widget_show_all(supression);

}


void
on_buttonback4_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *affichage;
window=lookup_widget(button,"affichage");
gtk_widget_hide(window);
affichage=create_aceuil();
gtk_widget_show_all(affichage);

}


void
on_buttoncree_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *entryCin;
GtkWidget *entrynom;
GtkWidget *entryprenom;
GtkWidget *entrymail;
GtkWidget *entrypass;
GtkWidget *output;
GtkWidget *spinbutton1;
int age;

FILE *ag;

char a[20], b[20], c[20], d[50], e[20],civ[20];

spinbutton1=lookup_widget(button, "spinbutton1");
age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton1));

entryCin=lookup_widget(button,"entryCin");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(entryCin)));

combobox1=lookup_widget(button, "combobox1");
strcpy(civ,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

entrynom=lookup_widget(button,"entrynom");
strcpy(b,gtk_entry_get_text(GTK_ENTRY(entrynom)));

entryprenom=lookup_widget(button,"entryprenom");
strcpy(c,gtk_entry_get_text(GTK_ENTRY(entryprenom)));

entrymail=lookup_widget(button,"entrymail");
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entrymail)));

entrypass=lookup_widget(button,"entrypass");
strcpy(e,gtk_entry_get_text(GTK_ENTRY(entrypass)));

ag=fopen("/home/mohamedsouguir/Projects/projet1/src/agent.txt","a+");

char a1[20],age1[12], b1[20], c1[20], d1[20], e1[50],civ1[20], ext[60];
int x=0;

if (ag!=NULL)
{
while (fscanf(ag,"%s %s %s %s %s %s %s\n",civ1,age1,a1,b1,c1,d1,e1)!=EOF)
{
   if ((strcmp(a, a1)== 0))
    { 
	strcpy(ext,"existing account");
	output=lookup_widget(button,"labelexist");
	gtk_label_set_text(GTK_LABEL(output),ext);
        x=1;	
        break;
    }
}}
if(x==0) {fprintf(ag,"%s %d %s %s %s %s %s\n",civ,age,a,b,c,d,e);
strcpy(ext,"Agent aded");
	output=lookup_widget(button,"labelexist");
	gtk_label_set_text(GTK_LABEL(output),ext);
char a2[20]="", b2[20]="", c2[20]="", d2[20]="", e2[20]="";
gtk_entry_set_text(GTK_ENTRY(entryCin),a2);
gtk_entry_set_text(GTK_ENTRY(entrynom),b2);
gtk_entry_set_text(GTK_ENTRY(entryprenom),c2);
gtk_entry_set_text(GTK_ENTRY(entrymail),d2);
gtk_entry_set_text(GTK_ENTRY(entrypass),e2);


}
fclose(ag);
}




void
on_buttonback6_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *update;
window=lookup_widget(button,"update");
gtk_widget_hide(window);
update=create_aceuil();
gtk_widget_show_all(update);

}







void
on_buttonediter_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *entrycinagent;
GtkWidget *output;
FILE *ag;
FILE *f;
FILE *h;
char a[20];
char a1[20],age1[12], b1[20], c1[20], d1[20], e1[20],civ1[20], ext[60];
int x=0;
GtkWidget *entrypassadmin;
FILE *ad;
char b[20];
char b2[20];
int y=0;
char gen[20], age[3], cin[10], name[50], sur[40], mail[50], pass[50],a2[50];
GtkWidget *combobox200;
GtkWidget *entryname1;
GtkWidget *entrysurname1;
GtkWidget *entrymail1;
GtkWidget *entrypass1;
GtkWidget *spinbutton200;
char  b4[20], c[20], d[20], e[20],civ[20];


entrycinagent=lookup_widget(button,"entrycinagent");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(entrycinagent)));
ag=fopen("/home/mohamedsouguir/Projects/projet1/src/agent.txt","a+");



while (fscanf(ag,"%s %s %s %s %s %s %s\n",civ1,age1,a1,b1,c1,d1,e1)!=EOF)
{
   if ((strcmp(a, a1)== 0))
    { 
        x=1;	
        break;
    }
}

entrypassadmin=lookup_widget(button,"entrypassadmin");
strcpy(b,gtk_entry_get_text(GTK_ENTRY(entrypassadmin)));
ad=fopen("/home/mohamedsouguir/Projects/projet1/src/admin.txt","a+");


while(fscanf(ad,"%s %s",a2,b2))
{
   if ((strcmp(b, b2)== 0))
    { 
        y=1;	
        
    }
}

if((x==1) & (y==1))
	
{
f=fopen("/home/mohamedsouguir/Projects/projet1/src/agent.txt","r");
 if (f!=NULL){ 
              while (fscanf(f,"%s %s %s %s %s %s %s\n", gen , age, cin,name, sur, mail,pass)!=EOF)
                    {
			if (strcmp(a,cin)!=0)
                       {
                        h=fopen("/home/mohamedsouguir/Projects/projet1/src/agent1.txt","a+");
fprintf(h,"%s %s %s %s %s %s %s \n", gen , age, cin, name, sur, mail,pass );
fclose(h);
			}
			else 
{
x=x+1;
spinbutton200=lookup_widget(button, "spinbutton200");
int age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton200));

combobox200=lookup_widget(button, "combobox200");
strcpy(civ,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox200)));

entryname1=lookup_widget(button,"entryname1");
strcpy(b4,gtk_entry_get_text(GTK_ENTRY(entryname1)));

entrysurname1=lookup_widget(button,"entrysurname1");
strcpy(c,gtk_entry_get_text(GTK_ENTRY(entrysurname1)));

entrymail1=lookup_widget(button,"entrymail1");
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entrymail1)));

entrypass1=lookup_widget(button,"entrypass1");
strcpy(e,gtk_entry_get_text(GTK_ENTRY(entrypass1)));
 h=fopen("/home/mohamedsouguir/Projects/projet1/src/agent1.txt","a+");
fprintf(h,"%s %d %s %s %s %s %s \n",civ,age,a,b,c,d,e );
fclose(h);

				 
}}}
fclose(f);
remove("/home/mohamedsouguir/Projects/projet1/src/agent.txt");
rename("/home/mohamedsouguir/Projects/projet1/src/agent1.txt","/home/mohamedsouguir/Projects/projet1/src/agent.txt");
strcpy(ext,"ok");
}
else 
{strcpy(ext,"Cin or Password incorrect");
	output=lookup_widget(button,"labelagent");
	gtk_label_set_text(GTK_LABEL(output),ext);
}
}


void
on_buttonsupp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE *f;
FILE *h;
FILE *ad;

char a[40],b[40];
int x=0;
int y=0;
GtkWidget *entrypassad;
GtkWidget *entrycinsupp;
GtkWidget *output;
char msg[50];
char gen[20], age[3], cin[10], name[50], sur[40], mail[50], pass[50];
entrycinsupp=lookup_widget(button,"entrycinsupp");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(entrycinsupp)));
f=fopen("/home/mohamedsouguir/Projects/projet1/src/agent.txt","r");
 if (f!=NULL){ 
              while (fscanf(f,"%s %s %s %s %s %s %s\n", gen , age, cin, name, sur, mail,pass)!=EOF)
                    {
			if (strcmp(a,cin)!=0)
                       {
                        h=fopen("/home/mohamedsouguir/Projects/projet1/src/agent1.txt","a+");
fprintf(h,"%s %s %s %s %s %s %s \n", gen , age, cin, name, sur, mail,pass );
fclose(h);
			}else {x=1;}}}
fclose(f);

entrypassad=lookup_widget(button,"entrypassad");
strcpy(b,gtk_entry_get_text(GTK_ENTRY(entrypassad)));

   if ((strcmp(b, "0000")==0))
    { 
        y=1;	
        
    }

if ((x==1) & (y==1))
	{
	 output=lookup_widget(button,"label15");
	 strcpy(msg,"deleted agent");
         gtk_label_set_text(GTK_LABEL(output),msg);
	 remove("/home/mohamedsouguir/Projects/projet1/src/agent.txt");
	 rename("/home/mohamedsouguir/Projects/projet1/src/agent1.txt","/home/mohamedsouguir/Projects/projet1/src/agent.txt");
         }

	else   
	{    
	 output=lookup_widget(button,"label15");
         strcpy(msg,"Cin or password incorrect");
         gtk_label_set_text(GTK_LABEL(output),msg);
	 remove("agent.txt");
	 rename("agent1.txt","agent.txt");
	}



}








#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonct.h"
#include <stdio.h>


void
on_checkbutton2_toggled                (GtkToggleButton *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window4;

window1=lookup_widget(button,"window1");

window4=lookup_widget(button,"window4");
window4=create_window4();
gtk_widget_show(window4);
}


void
on_checkbutton1_toggled                (GtkToggleButton *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;

window1=lookup_widget(button,"window1");

window2=lookup_widget(button,"window2");
window2=create_window2();
gtk_widget_show(window2);
}


void on_button1_clicked (GtkButton *objet,  gpointer user_data)
{FILE *h;
  char id[20];
 char nom[20];
 char prenom[20];
 char mail[20];
 char mdp[20];
 char nationalite[20];
 char pays[20];
 char genre[20];
 char cin[20];
 int age;
 char id1[20];
 char nom1[20];
 char prenom1[20];
 char mail1[20];
 char mdp1[20];
 char nationalite1[20];
 char pays1[20];
 char genre1[20];
 char cin1[20];
 int age1;
 char msg[50];
 GtkWidget *a;
 GtkWidget *b;
 GtkWidget *c;
 GtkWidget *d;
 GtkWidget *e;
 GtkWidget *f;
 GtkWidget *CB1;
 GtkWidget *CB2;
 GtkWidget *CB3;
 GtkWidget *sp1;
 GtkWidget *output;
 int x=0;
    a=lookup_widget(objet,"entry1");
    strcpy(nom,gtk_entry_get_text(GTK_ENTRY(a)));
    b=lookup_widget(objet,"entry2");
    strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(b))); 
    CB1=lookup_widget(objet,"combobox1");
    strcpy(nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(CB1)));
    CB2=lookup_widget(objet,"combobox2");
    strcpy(pays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(CB2)));
    CB3=lookup_widget(objet,"combobox3");
    strcpy(genre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(CB3)));
    c=lookup_widget(objet,"entry3");
    strcpy(cin,gtk_entry_get_text(GTK_ENTRY(c)));
    d=lookup_widget(objet,"entry4");
    strcpy(mail,gtk_entry_get_text(GTK_ENTRY(d)));
     sp1=lookup_widget(objet,"spinbutton1");
     age=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(sp1));
    e=lookup_widget(objet,"entry5");
    strcpy(id,gtk_entry_get_text(GTK_ENTRY(e)));
    f=lookup_widget(objet,"entry6");
    strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(f)));
h=fopen("/home/sirine/Projects/ff.txt","a+");
 if (h!=NULL){ while (fscanf(h,"%s %s %s %s %s %s %s %s %s %d    \n", id1 , nom1, prenom1,nationalite1, pays1, mail1, genre1, mdp1,cin1 ,&age1)!=EOF)
 {    
			if (strcmp(id,id1)==0){
                        output=lookup_widget(objet,"label15");
                        strcpy(msg,"id invalide");
                        gtk_label_set_text(GTK_LABEL(output),msg);
x=1;
break;}
else{output=lookup_widget(objet,"label15");
                        strcpy(msg,"operation effectué ");
                        gtk_label_set_text(GTK_LABEL(output),msg);}}}
                                    
			
    if( x==0){fprintf(h,"%s %s %s %s %s %s %s %s %s %d \n", id , nom, prenom, nationalite, pays, mail, genre, mdp,cin, age);
fclose(h);}

}







void on_button2_clicked (GtkButton *button, gpointer user_data)
{

FILE*f;
GtkWidget *output;
GtkWidget *entry8;
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry11;
GtkWidget *entry12;
GtkWidget *entry13;
GtkWidget *entry14;
GtkWidget *entry15;
GtkWidget *entry16;
GtkWidget *l;
  char id[20];
 char nom[20];
 char prenom[20];
 char mail[20];
 char mdp[20];
 char nationalite[20];
 char pays[20];
 char genre[20];
 char cin[20];
 char age[30];
char a[30],b[30],c[30],e[30],g[30],i[30],j[30],z[30],o[30],w[30];
char msg[30];
int x=0;


l=lookup_widget(button,"entry7");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(l)));
f=fopen("/home/sirine/Projects/ff.txt","r");
 if (f!=NULL){ 
              while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s  \n", id , nom, prenom, nationalite, pays, mail, genre, mdp,cin ,age)!=EOF)
                    {
			if (strcmp(a,id)==0)
                 {strcpy(b,nom);
                  strcpy(c,prenom);
                  strcpy(e,nationalite);
                  strcpy(g,pays);
 		  strcpy(i,mail);
		  strcpy(j,genre);
		strcpy(z,mdp);
		strcpy(w,cin);
		strcpy(o,age);
		x=1;
		break;}}}
            fclose(f);

            if (x!=1){output=lookup_widget(button,"label28");
                        strcpy(msg,"id invalide");
                        gtk_label_set_text(GTK_LABEL(output),msg);}
           else{
                  entry8=lookup_widget(button,"entry8");
		  gtk_entry_set_text(GTK_ENTRY(entry8),b);

                  entry9=lookup_widget(button,"entry9");
	          gtk_entry_set_text(GTK_ENTRY(entry9),c);
                  entry10=lookup_widget(button,"entry10");                 
                  gtk_entry_set_text(GTK_ENTRY(entry10),e);

                  

                  entry11=lookup_widget(button,"entry11");		 
                  gtk_entry_set_text(GTK_ENTRY(entry11),g);

                  entry12=lookup_widget(button,"entry12");
                  gtk_entry_set_text(GTK_ENTRY(entry12),w);
                  
		  entry13=lookup_widget(button,"entry13");                  
                  gtk_entry_set_text(GTK_ENTRY(entry13), j);


entry14=lookup_widget(button,"entry14");                
gtk_entry_set_text(GTK_ENTRY(entry14),0);

entry15=lookup_widget(button,"entry15");
               gtk_entry_set_text(GTK_ENTRY(entry15),i);

entry16=lookup_widget(button,"entry16");               
gtk_entry_set_text(GTK_ENTRY(entry16),z);

}





}



void on_button3_clicked  (GtkButton       *objet, gpointer         user_data)
{

FILE *f;
FILE *h;
  char id[20];
 char nom[20];
 char prenom[20];
 char mail[20];
 char mdp[20];
 char nationalite[20];
 char pays[20];
 char genre[20];
 char cin[20];
 char age[30];
char a[40];
int x=0;
GtkWidget *i;
GtkWidget *output;
GtkWidget *entry8;
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry11;
GtkWidget *entry12;
GtkWidget *entry13;
GtkWidget *entry14;
GtkWidget *entry15;
GtkWidget *entry16;
char msg[50];
i=lookup_widget(objet,"entry7");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(i)));
f=fopen("/home/sirine/Projects/ff.txt","r");
 if (f!=NULL){ 
              while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s    \n", id , nom, prenom, nationalite, pays, mail, genre, mdp,cin ,age)!=EOF)
                    {
			if (strcmp(a,id)!=0)
                       {
                        h=fopen("/home/sirine/Projects/ff1.txt","a+");
fprintf(h,"%s %s %s %s %s %s %s %s %s %s    \n", id , nom, prenom, nationalite, pays, mail, genre,mdp,cin, age );
fclose(h);
			}else {x=x+1;}}}
fclose(f);

      if (x!=0)  { output=lookup_widget(objet,"label28");
         strcpy(msg,"operation effectuer ");
         gtk_label_set_text(GTK_LABEL(output),msg);}

      else   {    output=lookup_widget(objet,"label28");
         strcpy(msg,"operation invalide");
         gtk_label_set_text(GTK_LABEL(output),msg);}


remove("/home/sirine/Projects/ff.txt");
rename("/home/sirine/Projects/ff1.txt","/home/sirine/Projects/ff.txt");}






void
on_button4_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
FILE *f;
FILE *h;
  char id[20];
 char nom[20];
 char prenom[20];
 char mail[20];
 char mdp[20];
 char nationalite[20];
 char pays[20];
 char genre[20];
 char cin[20];
 char age[30];
 char id1[20];
 char nom1[20];
 char prenom1[20];
 char mail1[20];
 char mdp1[20];
 char nationalite1[20];
 char pays1[20];
 char genre1[20];
 char cin1[20];
 char age1[20];
char a[40];
int x=0;
GtkWidget *k;
GtkWidget *output;

GtkWidget *b;
GtkWidget *c;
GtkWidget *e;
GtkWidget *g;
GtkWidget *w;
GtkWidget *j;
GtkWidget *o;
GtkWidget *i;
GtkWidget *z;
char msg[50];
k=lookup_widget(objet,"entry7");
strcpy(a,gtk_entry_get_text(GTK_ENTRY(k)));
f=fopen("/home/sirine/Projects/ff.txt","r");
 if (f!=NULL){ h=fopen("/home/sirine/Projects/ff1.txt","a+");
              while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s    \n", id , nom, prenom, nationalite, pays, mail, genre, mdp,cin ,age)!=EOF)
                    {
			if (strcmp(a,id)!=0)
                       {
                        
fprintf(h,"%s %s %s %s %s %s %s %s %s %s    \n", id , nom, prenom, nationalite, pays, mail, genre,mdp,cin, age );

	}else { b=lookup_widget(objet,"entry8");
                               strcpy(nom,gtk_entry_get_text(GTK_ENTRY(b)));

 			       c=lookup_widget(objet,"entry9");
                               strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(c)));
 			       e=lookup_widget(objet,"entry10");
                               strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(e)));
 			       g=lookup_widget(objet,"entry11");
                               strcpy(pays1,gtk_entry_get_text(GTK_ENTRY(g)));
			       w=lookup_widget(objet,"entry12");
                               strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(w)));
 			       j=lookup_widget(objet,"entry13");
                               strcpy(genre1,gtk_entry_get_text(GTK_ENTRY(j)));
 			       o=lookup_widget(objet,"entry14");
                               strcpy(age1,gtk_entry_get_text(GTK_ENTRY(o)));
 			       i=lookup_widget(objet,"entry15");
                               strcpy(mail1,gtk_entry_get_text(GTK_ENTRY(i)));
 			       z=lookup_widget(objet,"entry16");
                               strcpy(mdp1,gtk_entry_get_text(GTK_ENTRY(z)));


fprintf(h,"%s %s %s %s %s %s %s %s %s %s    \n", id , nom1, prenom1, nationalite1, pays1, mail1, genre1,mdp1,cin1, age1 );




x=x+1;}}}
fclose(h);
fclose(f);

      if (x!=0)  { output=lookup_widget(objet,"label28");
         strcpy(msg,"modifications effectuées avec succé");
         gtk_label_set_text(GTK_LABEL(output),msg);}

      else   {    output=lookup_widget(objet,"label28");
         strcpy(msg,"operation invalide");
         gtk_label_set_text(GTK_LABEL(output),msg);}


remove("/home/sirine/Projects/ff.txt");
rename("/home/sirine/Projects/ff1.txt","/home/sirine/Projects/ff.txt");}





void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window3;

window3=lookup_widget(button,"window3");
gtk_widget_hide(window1);
window1=lookup_widget(button,"window1");
window1=create_window1();
gtk_widget_show(window1);

}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window3;
GtkWidget *treeview1;
window1=lookup_widget(button,"window1");
gtk_widget_hide(window1);
window3=lookup_widget(button,"window3");
window3=create_window3();
gtk_widget_show(window3);
treeview1=lookup_widget(window3,"treeview1");
affich(treeview1);
}



void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window3;

window3=lookup_widget(button,"window2");
gtk_widget_hide(window3);

}


void
on_button8_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget  *input;
char rep[50];
char m[50];

GtkWidget *window5;
GtkWidget *window4;
input=lookup_widget(objet,"entry17");
strcpy(m,"d99t26");
strcpy(rep,gtk_entry_get_text(GTK_ENTRY(input)));
    if (strcmp(rep,m)==0){gtk_widget_destroy(window4);}
    else{window4=lookup_widget(objet,"window4");
window5=lookup_widget(objet,"window5");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_destroy(window4);}
}


void
on_button9_activate                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4;
GtkWidget *window5;
gtk_widget_show_all(window4);
window4=lookup_widget(objet,"window4");
window5=lookup_widget(objet,"window5");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_destroy(window5);
}


void
on_button10_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget  *input;
char rep[50];
char m[50];
GtkWidget *window1;
GtkWidget *window2;
input=lookup_widget(objet,"entry18");
window2=lookup_widget(objet,"window5");
strcpy(m,"dgfy9g");
strcpy(rep,gtk_entry_get_text(GTK_ENTRY(input)));
    if (strcmp(rep,m)==0){gtk_widget_destroy(window2);}
    else{window1=lookup_widget(objet,"window4");
window1=lookup_widget(objet,"window4");
window1=create_window1();
gtk_widget_show(window1);
gtk_widget_destroy(window2);}
}


void
on_button11_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{GtkWidget *window4;
GtkWidget *window5;
gtk_widget_show_all(window5);
window5=lookup_widget(objet,"window4");
window4=lookup_widget(objet,"window4");
window4=create_window4();
gtk_widget_show(window4);
gtk_widget_destroy(window5);

}


void
on_button9_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4;
GtkWidget *window5;
gtk_widget_show_all(window4);
window4=lookup_widget(objet,"window4");
window5=lookup_widget(objet,"window5");
window5=create_window5();
gtk_widget_show(window5);
gtk_widget_destroy(window5);
}


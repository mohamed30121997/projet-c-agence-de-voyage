#include <string.h>
#include "fonct.h"
#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>

void affich(GtkWidget *plistview)
{ 
enum { 
       COL_ID,
       COL_NOM,
       COL_PRENOM,
       COL_NATIONALITE,
       COL_PAYS,
       COL_MAIL,	
       COL_GENRE,
       COL_MDP,
       COL_CIN,
       COL_AGE,
       NUM_COLS
      };
char id[20],n[20],p[12],na[20],pa[20],m[20],g[20],mdp[20],ci[20],ag[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f1;
f1=fopen("/home/sirine/Projects/ff.txt","r");
if(f1!=NULL){
       while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s\n",id,n,p,na,pa,m,g,mdp,ci,ag)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_ID,id ,
		          COL_NOM, n,
		          COL_PRENOM,p,
			  COL_NATIONALITE,na,
			  COL_PAYS,pa,
			  COL_MAIL,m,
			  COL_GENRE,g,
			  COL_MDP,mdp,
			  COL_CIN,ci,
			  COL_AGE,ag,
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("id",celrender,"text",COL_ID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("genre",celrender,"text",COL_NATIONALITE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes   ("nationalite",celrender,"text",COL_PAYS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mail",celrender,"text",COL_MAIL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
     
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("pays",celrender,"text",COL_GENRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
     
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mdp",celrender,"text",COL_MDP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	
        
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("cin",celrender,"text",COL_CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	

gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f1);
}

